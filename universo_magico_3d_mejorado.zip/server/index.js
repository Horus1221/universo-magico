const express=require("express"),http=require("http"),{Server}=require("socket.io"),path=require("path");
const app=express(),server=http.createServer(app),io=new Server(server);
app.use(express.static(path.join(__dirname,"../public")));
io.on("connection",s=>{s.emit("system","Conectado al Reino ✦");s.on("chat",m=>{m=String(m).trim().slice(0,300);if(m)io.emit("chat",m)})});
app.get("/health",(q,r)=>r.json({ok:true}));
server.listen(process.env.PORT||3000,"0.0.0.0",()=>console.log("Universo Magico listo"));