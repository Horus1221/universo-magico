# Universo Mágico — completo 0.3

Cliente móvil + servidor multijugador + PostgreSQL.

Incluye joystick táctil, creación de personaje, login/registro, Socket.IO,
persistencia de vida/maná/oro/personaje y respawn.

Variables de entorno:
DATABASE_URL
JWT_SECRET
PORT (opcional)
CLIENT_ORIGIN (opcional)

Arranque:
1. Ejecutar server/schema.sql en PostgreSQL.
2. npm install
3. npm run server

El servidor sirve client/ y Socket.IO en el mismo dominio.
