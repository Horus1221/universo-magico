const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CLIENT_ORIGIN || '*' } });
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error('Falta JWT_SECRET en las variables de entorno.');

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'client')));

function sign(userId) {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '7d' });
}

async function auth(req, res, next) {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'No autorizado' });
  }
}

app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password || username.length < 3 || password.length < 8)
    return res.status(400).json({ error: 'Usuario >= 3 caracteres y contraseña >= 8.' });

  try {
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      'INSERT INTO users(username,password_hash) VALUES($1,$2) RETURNING id,username',
      [username, hash]
    );
    res.json({ token: sign(result.rows[0].id), user: result.rows[0] });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Ese usuario ya existe.' });
    console.error(e);
    res.status(500).json({ error: 'Error del servidor.' });
  }
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const r = await pool.query('SELECT * FROM users WHERE username=$1', [username]);
  if (!r.rowCount || !(await bcrypt.compare(password, r.rows[0].password_hash)))
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  res.json({ token: sign(r.rows[0].id), user: { id: r.rows[0].id, username } });
});

app.get('/api/character', auth, async (req, res) => {
  const r = await pool.query('SELECT * FROM characters WHERE user_id=$1', [req.user.userId]);
  res.json(r.rows[0] || null);
});

app.post('/api/character', auth, async (req, res) => {
  const { name, race, className, appearance = {}, equipment = {} } = req.body;
  const r = await pool.query(`
    INSERT INTO characters(user_id,name,race,class,appearance,equipment)
    VALUES($1,$2,$3,$4,$5,$6)
    ON CONFLICT(user_id) DO UPDATE SET
      name=EXCLUDED.name, race=EXCLUDED.race, class=EXCLUDED.class,
      appearance=EXCLUDED.appearance, equipment=EXCLUDED.equipment,
      updated_at=NOW()
    RETURNING *`,
    [req.user.userId, name, race, className, appearance, equipment]
  );
  res.json(r.rows[0]);
});

app.post('/api/character/save', auth, async (req, res) => {
  const { hp, mana, gold, appearance, equipment } = req.body;
  const r = await pool.query(`
    UPDATE characters SET hp=$1,mana=$2,gold=$3,appearance=$4,equipment=$5,updated_at=NOW()
    WHERE user_id=$6 RETURNING *`,
    [hp, mana, gold, appearance, equipment, req.user.userId]
  );
  res.json(r.rows[0]);
});

const online = new Map();

io.use((socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    socket.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { next(new Error('No autorizado')); }
});

io.on('connection', async socket => {
  const r = await pool.query(
    'SELECT id,name,race,class,hp,mana,gold,appearance,equipment FROM characters WHERE user_id=$1',
    [socket.user.userId]
  );
  if (!r.rowCount) return socket.disconnect(true);

  const c = r.rows[0];
  online.set(socket.user.userId, { socketId: socket.id, x: 500, y: 350, character: c });

  socket.emit('world:init', {
    self: { id: c.id, name: c.name, race: c.race, class: c.class, x: 500, y: 350, hp: c.hp, mana: c.mana, gold: c.gold, appearance: c.appearance, equipment: c.equipment },
    players: [...online.entries()]
      .filter(([id]) => Number(id) !== Number(socket.user.userId))
      .map(([id,v]) => ({ id: Number(id), ...v.character, x: v.x, y: v.y }))
  });

  socket.broadcast.emit('player:join', { id: c.id, name: c.name, race: c.race, class: c.class, x: 500, y: 350, appearance: c.appearance });

  socket.on('player:move', ({x,y}) => {
    const p = online.get(socket.user.userId);
    if (!p) return;
    p.x = Math.max(30, Math.min(970, Number(x)));
    p.y = Math.max(30, Math.min(670, Number(y)));
    socket.broadcast.emit('player:move', { id: c.id, x: p.x, y: p.y });
  });

  socket.on('spell:cast', async ({ manaCost = 15 }) => {
    const p = online.get(socket.user.userId);
    if (!p || p.character.mana < manaCost) return socket.emit('spell:failed', { reason: 'mana' });
    p.character.mana -= manaCost;
    await pool.query('UPDATE characters SET mana=$1,updated_at=NOW() WHERE user_id=$2',
      [p.character.mana, socket.user.userId]);
    socket.emit('spell:success', { mana: p.character.mana });
  });

  socket.on('player:damage', async ({ amount }) => {
    const p = online.get(socket.user.userId);
    if (!p) return;
    p.character.hp = Math.max(0, p.character.hp - Math.max(0, Number(amount)));
    if (p.character.hp === 0) {
      p.character.hp = p.character.max_hp || 100;
      p.x = 500; p.y = 350; // respawn in Lumina
      await pool.query(
        'UPDATE characters SET hp=$1,updated_at=NOW() WHERE user_id=$2',
        [p.character.hp, socket.user.userId]
      );
      socket.emit('player:respawn', { x: p.x, y: p.y, hp: p.character.hp, town: p.character.respawn_town || 'Lumina' });
    } else {
      await pool.query('UPDATE characters SET hp=$1,updated_at=NOW() WHERE user_id=$2',
        [p.character.hp, socket.user.userId]);
      socket.emit('player:hp', { hp: p.character.hp });
    }
  });

  socket.on('disconnect', () => {
    online.delete(socket.user.userId);
    socket.broadcast.emit('player:leave', { id: c.id });
  });
});

server.listen(process.env.PORT || 3000, () =>
  console.log('Servidor del Universo Mágico iniciado.')
);